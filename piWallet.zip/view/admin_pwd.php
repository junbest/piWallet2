<?php if (!defined("IN_WALLET")) { die("Auth Error!"); } ?>
