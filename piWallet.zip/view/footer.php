<?php if (!defined("IN_WALLET")) { die("Auth Error!."); } ?>
<?php //PLEASE DO NOT REMOVE OR CHANGE THE POWERED BY LINK. THIS IS THE ONLY RECOGNITION I ASK FOR ?>
            </div>
        </div>

    </body>
<b><center><p>Powered by <a href="http://github.com/johnathanmartin/piWallet">piWallet</a></p>
</center></b>
</html>
