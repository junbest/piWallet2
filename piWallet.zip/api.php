<?php
#API IS DISABLED BY DEFAULT AS ITS STILL IN DEV. ENABLE AT YOUR OWN RISK.
define("IN_WALLET", false); #TO ENABLE SET TO TRUE
###################################################

include('common.php');

$_POST = (array)json_decode(file_get_contents("php://input"));//added for raw format

if(!empty($_POST) && isset($_POST['username']))
{
	try{
		$data = $_GET['a'];
		$username = $_POST['username'];
		if($data=='get_balance')
		{
			$client = new Client($rpc_host, $rpc_port, $rpc_user, $rpc_pass);
			$apibal = $client->getBalance($username) - $fee;
			echo json_encode(array("username" => $username, "balance" => $apibal));
		}
		elseif($data=='get_address')
		{
			
			$client = new Client($rpc_host, $rpc_port, $rpc_user, $rpc_pass);
			$addr = $client->getAddress($username);
			echo json_encode(array( "username" => $username, "address" => $addr));
		}
		elseif($data=='get_address_list')
		{
			
			$client = new Client($rpc_host, $rpc_port, $rpc_user, $rpc_pass);
			$addr = $client->getAddressList($username);
			echo json_encode(array( "username" => $username, "addresses" => $addr));
		}
		elseif($data=='get_transaction_list')
		{
			
			$client = new Client($rpc_host, $rpc_port, $rpc_user, $rpc_pass);
			$trans = $client->getTransactionList($username);
			echo json_encode(array( "username" => $username, "transactions" => $trans));
		}
		elseif($data=='get_new_address')
		{
			
			$client = new Client($rpc_host, $rpc_port, $rpc_user, $rpc_pass);
			$addr = $client->getNewAddress($username);
			echo json_encode(array( "username" => $username, "new_address" => $addr));
		}
		elseif($data=='withdraw')
		{
			
			$to_address = $_POST['to_address'];
			$to_amount = $_POST['to_amount'];
			if($to_address!='' && $to_amount!='' && is_numeric($to_amount) )
			{
				$client = new Client($rpc_host, $rpc_port, $rpc_user, $rpc_pass);
				$balance = $client->getBalance($username);
				if($to_amount > $balance)
					echo json_encode(array("error" => "Withdrawal amount exceeds your wallet balance"));
				else
				{	
					$addr = $client->withdraw($username,$to_address,$to_amount);
					echo json_encode(array( "username" => $username, "address" => $addr));
				}
			}
			else
			{
				echo json_encode(array("error" => "Address and Amount is required"));
			}	
		}
	}
	catch(exception $e)
	{
		echo json_encode(array("error" => "$e"));
	}

}
else
{
	echo json_encode(array("error" => "Username is required"));
}
?>
